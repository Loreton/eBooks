# xxx!/usr/bin/python3
# Progamma per testare regex
#
# updated by ...: Loreto Notarantonio
# Version ......: 26-09-2020 10.38.44
#

import re
import json
import pdb



#################################
#
#################################
def FindAll(p, data, fPRINT=False):
    if fPRINT:print(p)
    if isinstance(data, str): data=[data]
    result=[]
    occurrencies = p.findall(' '.join(data))
    if  occurrencies:
        if fPRINT:print(occurrencies)
        result.extend(occurrencies)

    return result

#################################
# return: {
#       'word1': (start_pos, end_pos),
#       'word2': (start_pos, end_pos)
#       'word..n': (start_pos, end_pos)
#       }
#################################
def FindIter(p, data, fPRINT=False):
    if fPRINT:print(p)
    if isinstance(data, str): data=[data]
    # occurrencies2 = [(i.span(), i.start(), i.end(), i.group()) for i in p.finditer(' '.join(data))]
    occurrencies={}
    for i in p.finditer(' '.join(data)):
        item=i.group()
        if not item in occurrencies:
            occurrencies[item]=[]
        occurrencies[item].append(i.span())

    if fPRINT:
        print('FindIter:\n      ', json.dumps(occurrencies, indent=4, sort_keys=True))

    return occurrencies



#################################
# return: {
#       'item': (start_pos, end_pos),
#       }
#################################
def Search(p, data, fPRINT=False):
    # pdb.set_trace()
    if fPRINT:print(p)
    if isinstance(data, str): data=[data]
    result={}

    x=p.search(' '.join(data), re.IGNORECASE)
    if  x:
        # print(x)
        item=x.group()
        result[item]=x.span()
        # result=x.span()

    if fPRINT:
        print('Search:\n      ', json.dumps(result, indent=4, sort_keys=True))

    return result


#################################
# - search any word (OR)
def OR(words):
    # p=re.compile(r'\b(?:{0})\b'.format('|'.join(words)), re.IGNORECASE)
    p=re.compile(r'\b({0})\b'.format('|'.join(words)), re.IGNORECASE)
    FindIter(p, data['content'])


#################################
# - search all words (AND) sequence order
#################################
def AND(strings, word_bnd=False):
    if word_bnd:
        base_pattern=r'\b({0})\b'
    else:
        base_pattern=r'({0})'

    p=re.compile(base_pattern.format('.*'.join(strings)), re.IGNORECASE)

    FindIter(p, data['content'])

#################################
# - search all words (AND) any order
# - + veloce di AND3
#################################
def AND2(data, strings, word_bnd=False):
    if word_bnd:
        base_pattern=r'\b({item})\b'
    else:
        base_pattern=r'({item})'

    result={}
    counter=0
    for item in strings:
        p=re.compile(base_pattern.format(**locals()), re.IGNORECASE)
        _res=Search(p, data, fPRINT=True) # uso il search perché si ferma alla first occurrency
        if _res:
            counter+=1
            result.update(_res) # merge dict

    fFOUND = counter==len(strings)
    print('Found:', fFOUND)
    if fFOUND:
        return result
    else:
        return {}


#################################
# - search all words (AND) any order
# - - veloce di AND2
# - in compenso torna tutte le entries per ogni word
#################################
def AND3(data, strings, word_bnd=False):
    if word_bnd:
        base_pattern=r'\b({0})\b'
    else:
        base_pattern=r'({0})'
    result={}
    counter=0

    p=re.compile(base_pattern.format('|'.join(strings)), re.IGNORECASE)
    _list = FindIter(p, data, fPRINT=True)
    for item in strings:
        if item in _list:
            result[item] = _list
            counter+=1

    fFOUND = counter==len(strings)
    print('Found:', fFOUND)
    if fFOUND:
        return result
    else:
        return {}

# search between delimiters
from inspect import stack
from types import SimpleNamespace
def regex_search(value=None, prefix=None, suffix=None):
    dummy, programFile, lineNumber, func_name, lineCode, rest = stack()[0]

    # - change prefix and/or suffix
    if prefix or suffix:
        if prefix:
            setattr(eval(func_name), 'prefix', prefix)
            # setattr(regex_search, 'prefix', prefix)

        if suffix:
            setattr(eval(func_name), 'suffix', suffix)
            # setattr(regex_search, 'suffix', suffix)

        _prefix=getattr(func_name, 'prefix', '${').replace('$', '\\$')
        _suffix=getattr(func_name, 'suffix', '}').replace('$', '\\$')
        self._re=re.compile(f'{_prefix}(.*?){_suffix}', re.IGNORECASE)


    ret=SimpleNamespace(matched=False)

    if value:
        matched=self._re.search(value)
        if matched:
            ret.matched=True
            self.logger.info('MATCH FOUND:', str(matched))
            matched_str, ret.start_pos, ret.end_pos=matched.group(), matched.start(), matched.end()
            ret.name=matched_str.lstrip(self._prefix).rstrip(self._suffix) #- strip prefix and suffix

    return ret




#################################
# - search near words
#################################
def two_near_words(data, word1, word2, near):
    near='{'+ '{near[0]},{near[1]}'.format(**locals())+'}'
    p=re.compile(r'\b{word1}\W+(?:\w+\W+){near}?{word2}\b'.format(**locals()), re.IGNORECASE)
    result=FindIter(p, data, fPRINT=True)


if __name__ == '__main__':
    data = get_data()
    # words=['passate', 'diavolo','finita']
    words=['diavolo','finita', 'passate']
    words=['strillo','borsa', 'letto']
    words=['letto','borsa', 'strillo']
    strings=['illo','ors', 'etto']

    # regex_OR(words)
    # regex_AND(words)

    start = time.time()
    # regex_AND2(data['single_line2'], words)
    regex_AND2(data['content'], words)
    print(f'Time: {time.time() - start}')

    start = time.time()
    # regex_AND3(data['single_line2'], words)
    regex_AND3(data['content'], words)
    print(f'Time: {time.time() - start}')

    # regex_str_AND(words)
    # regex_two_near_words(word1='primo', word2='tutti', near=[1,3])
    # regex_two_near_words(word1='primo', word2='grazie', near=[0,0])


    # p=re.compile('stanza', re.IGNORECASE)
    # -----
    # p.findall(text)
    # p.findall(text, re.IGNORECASE)