# #############################################
#
# updated by ...: Loreto Notarantonio
# Version ......: 14-10-2020 16.17.55
#
# #############################################

import  sys; sys.dont_write_bytecode=True
import  os
from    benedict import benedict
from    types import SimpleNamespace
import  re
import  pyaml, yaml, json # https://pypi.org/project/pyaml/
from inspect import stack



#######################################################
# filename:  deve essere relative-path in quanto deve
#   poter essere letto anche all'interno dello zip file
#######################################################
def ResolveDictVars(d, myLogger, value_sep='/'):
    global logger
    logger=myLogger

    Resolve_copy(d, value_sep=value_sep)
    print(d["Servers"].dump())
    from lnLib.promptLN import prompt; prompt() # by Loreto
    Resolve_merge(d, value_sep=value_sep)
    Resolve_env_vars(d, value_sep=value_sep)
    Resolve_getValue(d, value_sep=value_sep)
    Resolve_internal_vars(d, value_sep=value_sep)

    return d



"""
    store_path1: "${var:/main/store/path/${kpval:/Servers/?/server_name}}"
    /Servers/?/server_name: ? sarà preso dal livello del key_path
    username:               realtive path at same level of key_path
    .../username:           realtive path at len(...) up_level of key_path
"""
def resolve_keypath(d, key_path, value, var_name, value_sep='/'):
    # print(key_path, var_name)
    keypath_sep=d.keypath_separator
    kp_keys=key_path.split(keypath_sep)

    if var_name.startswith('/'): # full keypath
        path_list=var_name[1:].split(value_sep) # skip '/'

    elif var_name.startswith('.'): # relative keypat. #dot indicate up_levels
        _word0, *_rest=var_name.split(value_sep)
        up_levels=len(_word0) # counts numbers of dots
        path_list = kp_keys[:-up_levels]
        path_list.extend(_rest)

    else: # relative path from current level
        path_list = kp_keys[:-1]
        path_list.append(var_name)

    my_path=[]
    for inx, level_name in enumerate(path_list):
        if level_name=='?':
            level_name=kp_keys[inx]
        my_path.append(level_name)
    path_name=value_sep.join(my_path)

    my_kp=path_name.replace(value_sep, keypath_sep)
    try:
        value=d[my_kp]
    except (Exception)  as e:
        print('\n   ERROR working wth key_path:', my_kp)
        logger.critical(str(e))

    return path_name, value




###################################################
#
###################################################
def Resolve_merge(d, value_sep='/'):
    keypath_sep=d.keypath_separator
    _re=regex_search(prefix='${merge:', suffix='}')
    flat = d.flatten_ln(regex=_re, in_keys=False, in_values=True)

    for key_path, val in flat.items():
        if key_path.startswith('templates'): continue
        var=regex_search(val)
        if var.matched:
            _src_ptr=d[var.name.replace(value_sep, keypath_sep)]
            parent_keypath, _=key_path.rsplit(keypath_sep, 1)
            d[parent_keypath].merge(_src_ptr, overwrite=False) # merge with current data
            d.remove([key_path])


###################################################
# copy value from key path to other
###################################################
def Resolve_copy(d, value_sep='/'):
    keypath_sep=d.keypath_separator
    _re=regex_search(prefix='${copy:', suffix='}')
    flat = d.flatten_ln(regex=_re, in_keys=False, in_values=True)
    pyaml.p(flat, indent=4)
    import pdb; pdb.set_trace() # by Loreto
    for key_path, val in flat.items():
        # if key_path.startswith('templates'): continue
        var=regex_search(val)
        if var.matched:
            var_name=var.name
            if var.name.startswith('/'): var_name=var.name[1:]
            _src_keypath=var_name.replace(value_sep, '.')
            _src_ptr=d[_src_keypath]

            if isinstance(_src_ptr, dict):
                d[key_path]=benedict.copy(_src_ptr)

            elif isinstance(_src_ptr, (list, tuple)):
                d[key_path]=_src_ptr[:]

            else: # come per il ${var:...
                d[key_path]=_src_ptr





###################################################
#
###################################################
def Resolve_env_vars(d, value_sep='/'):
    # keypath_sep=d.keypath_separator
    _re=regex_search(prefix='${env:', suffix='}')
    flat = d.flatten_ln(regex=_re, in_keys=False, in_values=True)


    for key_path, val in flat.items():
        if key_path.startswith('templates'): continue
        var=regex_search(val)
        if var.matched:
            new_val=val
            while True:
                var=regex_search(new_val)
                if var.matched:
                    my_default_val=f'ENVAR_{var.name}_NOT_FOUND'
                    _value=os.environ.get(var.name, my_default_val)

                    if _value==my_default_val:
                        _value=f'<<<<---- {var.name} NOT FOUND ---->>>>'
                        logger.error(f'''  unable to resolve statement:
                            {key_path}: {val}
                            {_value}'''.replace('  ', ' '), console=True)
                        logger.critical('...exiting')

                    new_val = f'{val[:var.start_pos]}{_value}{val[var.end_pos:]}'
                else:
                    break

            if not new_val==val:
                d[key_path]=new_val



###################################################
#
###################################################
def Resolve_getValue(d, value_sep='/'):
    keypath_sep=d.keypath_separator
    _re=regex_search(prefix='${getValue:', suffix='}')
    flat = d.flatten_ln(regex=_re, in_keys=False, in_values=True)

    for key_path, value in flat.items():
        if key_path.startswith('templates'): continue
        new_val=value
        while True:
            var=regex_search(new_val)
            if var.matched:
                path_name, _value=resolve_keypath(d, key_path=key_path, value=new_val, var_name=var.name)
                new_val = f'{new_val[:var.start_pos]}{_value}{new_val[var.end_pos:]}'
            else:
                break

        if not new_val==value:
            d[key_path]=new_val




###################################################
#
###################################################
def Resolve_internal_vars(d, value_sep='/'):
    keypath_sep=d.keypath_separator
    _re=regex_search(prefix='${var:', suffix='}')
    flat = d.flatten_ln(regex=_re, in_keys=False, in_values=True)

    for key_path, value in flat.items():
        if key_path.startswith('templates'): continue
        new_val=value
        while True:
            var=regex_search(new_val)

            if var.matched:
                path_name, _value=resolve_keypath(d, key_path=key_path, value=new_val, var_name=var.name)
                new_val = f'{new_val[:var.start_pos]}{_value}{new_val[var.end_pos:]}'

            else:
                break

        if not new_val==value:
            # key_item='.'.join(key_path.split(separator))
            d[key_path]=new_val






# search between delimiters
def regex_search(value=None, prefix=None, suffix=None):
    dummy, programFile, lineNumber, func_name, lineCode, rest = stack()[0]

    # - change prefix and/or suffix
    if prefix or suffix:
        if prefix: setattr(eval(func_name), 'prefix', prefix)
        if suffix: setattr(eval(func_name), 'suffix', suffix)
    else:
        prefix=getattr(eval(func_name), 'prefix')
        suffix=getattr(eval(func_name), 'suffix')


    _prefix=prefix.replace('$', '\\$')
    _suffix=suffix.replace('$', '\\$')

    pattern=f'{_prefix}(.*?){_suffix}'
    _re=re.compile(pattern, re.IGNORECASE)

    ret=SimpleNamespace(matched=False)

    if value:
        matched=_re.search(value)
        if matched:
            ret.matched=True
            logger.info('MATCH FOUND:', str(matched))
            matched_str, ret.start_pos, ret.end_pos=matched.group(), matched.start(), matched.end()
            # ltrip mi dàerrore se subito dopo mi trovo una 'u'
            # ret.name=matched_str.lstrip(prefix).rstrip(suffix) #- strip prefix and suffix
            llen=len(prefix)
            rlen=len(suffix)
            ret.name=matched_str[llen:-rlen] #- strip prefix and suffix
        return ret
    else:
        return _re


