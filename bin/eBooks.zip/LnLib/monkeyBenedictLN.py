#!/usr/bin/python
# -*- coding: iso-8859-1 -*-
#
# updated by ...: Loreto Notarantonio
# Version ......: 13-10-2020 08.13.00
#
# Scope:  aggiunge dei metodi al package python-benedict
# see test/benedict_test.py for sample
# ######################################################################################

from    benedict import benedict
from    benedict.utils import type_util
from    benedict.core import clone


'''
def _flatten_key(base_key, key, separator):
    if base_key and separator:
        return f'{base_key}{separator}{key}'
    return key


def _flatten_item(d, base_dict, base_key, separator, explode_lists=False, **kwargs): #  by Loreto:  21-09-2020 17.56.58
    # explode_lists=kwargs.get('explode_lists', False)
    new_dict = base_dict
    keys = list(d.keys())
    if 'index' in kwargs: #  by Loreto:  21-09-2020 17.56.50
        index=kwargs['index'] #  by Loreto:  21-09-2020 17.56.51
        base_key=f'{base_key}[{index}]' #  by Loreto:  21-09-2020 17.56.52

    for key in keys:
        new_key = _flatten_key(base_key, key, separator)
        value = d.get(key, None)
        if type_util.is_dict(value):
            new_value = _flatten_item(value,
                                      base_dict=new_dict,
                                      base_key=new_key,
                                      separator=separator,
                                      explode_lists=explode_lists)

            new_dict.update(new_value)
            continue

        elif explode_lists and type_util.is_list_or_tuple(value):
            for index, item in enumerate(value):
                if type_util.is_dict(item):
                    new_item = _flatten_item(item,
                                        base_dict=new_dict,
                                        base_key=new_key,
                                        separator=separator,
                                        explode_lists=explode_lists,
                                        index=index)
                    new_item.update(new_dict)
                    new_dict.update(new_item)
                else:
                    new_item={f'{base_key}{separator}{key}[{index}]': item}
                    new_item.update(new_dict)
                    new_dict.update(new_item)
        else:
            if new_key in new_dict:
                raise KeyError(f'Invalid key: "{new_key}", key already in flatten dict.')

            new_dict[new_key] = value


        # new_dict[new_key] = value
    return new_dict

'''


def flatten_ln(d, regex, in_keys=False, in_values=True):
    key_sep='/'
    flat = d.flatten(separator=key_sep)
    _my_flat={}
    for key, val in flat.items():
        if not val: continue
        if not isinstance(val, (str)): continue
        # print(f'{key}: {val}')
        if regex.search(val):
            key=key.replace(key_sep, d.keypath_separator)
            _my_flat[key] = val

    return _my_flat



'''
def get_keypath_value(d, keypath, default, separator='.'):
    if '[' not in keypath:
        return d.get(keypath, default) # go to benedict.get()

    lkeys=keypath.split(separator)
    ptr=d
    for key in lkeys:
        if key[-1]==']':
            key, index=key[:-1].split('[')
            ptr=ptr[key]
            if isinstance(ptr, list):
                ptr=ptr[int(index)]
        else:
            ptr=ptr[key]
    return ptr



# - bisonga cercare di capire se il path contiene anche un percorso di LIST
def set_keypath_value(d, keypath, value, separator='.', **kwargs):
    if '[' not in keypath:
        d[keypath]=value
        return

    lkeys=keypath.split(separator)

    # get pointer to last_key path
    ptr=get_keypath_value(d, separator.join(lkeys[:-1]), None)
    _last_item=lkeys[-1]
    if _last_item[-1]==']':
        last_key, index=_last_item[:-1].split('[')
        ptr=ptr[last_key]
        if isinstance(ptr, list):
            ptr[int(index)]=value
    else:
        ptr[last_key]=value




def search_string_in_keys(d, search_str, in_keys=False, in_values=False, separator='/', explode_lists=True):
    flat=flatten_ln(d, separator=separator, explode_lists=explode_lists)
    # import json;print(json.dumps(flat, indent=4, sort_keys=True))
    found={}
    for key, val in flat.items():
        if in_keys and search_str in key:
            found[key]=val
        elif in_values:
            if isinstance(val, (str, list, tuple)) and search_str in val:
                found[key]=val

    return found

'''

benedict.flatten_ln = flatten_ln
# benedict.getitem_ln = get_keypath_value
# benedict.setitem_ln = set_keypath_value
# benedict.search_ln  = search_string_in_keys


