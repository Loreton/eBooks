# #############################################
#
# updated by ...: Loreto Notarantonio
# Version ......: 08-10-2020 10.43.55
#
# #############################################

import sys, os
import argparse
from pathlib import Path

def common_options(my_parser):
    # --- common
    my_parser.add_argument('--db-name', default=None, help='db name. [DEFAULT=as defined in config_file]\n\n'+C.gCyan())

    my_parser.add_argument('------------  debug options', action='store_true')
    my_parser.add_argument('--go', action='store_true', help='default is --dry-run')
    my_parser.add_argument('--display-args', action='store_true', help='Display input paramenters')
    my_parser.add_argument('--debug', action='store_true',
                                help='display paths and input args\n\n'+C.gGreen())


    my_parser.add_argument('------------  overriding log options', action='store_true')
    my_parser.add_argument('--log-level', type=str, default='info',
                            choices=['critical','error','warning','info','debug','debug1','debug2','debug3'],
                            help='specify log level.')
    my_parser.add_argument('--log-console', action='store_true',
                            help='Activate log and write to console too.')

    my_parser.add_argument('--log-modules',
                                metavar='',
                                required=False,
                                default=[],
                                nargs='*',
                                help="""Activate log.
    E' anche possibile indicare una o più stringhe separate da BLANK
    per identificare le funzioni che si vogliono filtrare nel log.
    Possono essere anche porzioni di funcName.
    Es: --log-module nudule1 module2 module3
        """)






##############################################################
# - MAin Options
##############################################################
def mainOptions():
    parser=argparse.ArgumentParser(description='Program to process eBooks (by: Ln)',
                formatter_class=argparse.RawTextHelpFormatter)

    subparsers = parser.add_subparsers(title=C.gGreen()+"primary commands", dest='action', help='commands')
    """ dest=action mi permette di avere args.action che contiene il subparser scelto. """


    p_search = subparsers.add_parser ("search", formatter_class=argparse.RawTextHelpFormatter, help="search on several fields")
    p_search.add_argument('------------  search options', action='store_true', help=''+C.gYellow())  # solo per il colore
    p_search.add_argument('--book-id', help='Book_ID to search only on it', required=False, default=None)
    p_search.add_argument('--text-size', help='size of the found text to be displayed.', required=False, default=150, type=int)
    p_search.add_argument('--regex', help='use regex search', action='store_true')
    p_search.add_argument('--words',
                                metavar='',
                                required=True,
                                default=[],
                                nargs='*',
                                help="""strings to be searched. BLANK separator""")
    p_search.add_argument('--near',
                                metavar='',
                                required=False,
                                type=int,
                                default=[],
                                nargs='*',
                                help='''(int int) min max number of words separatings the words ''')
    p_search.add_argument('--field',
                                metavar='',
                                required=False,
                                default='content',
                                choices=['author', 'title', 'content', 'tags'],
                                # nargs='*',
                                help="field to be searched. BLANK separator [DEFAULT: content]\n\n")



    p_load = subparsers.add_parser ("load", formatter_class=argparse.RawTextHelpFormatter, help="Load book in DB")
    p_load.add_argument('------------  load options', action='store_true', help=''+C.gYellow())  # solo per il colore
    p_load.add_argument('--dir',default=None,  help='input dir [DEFAULT=as defined in config_file]')
    p_load.add_argument('--ftype', default='*.epub', help='file type to be included [DEFAULT=.epub]')
    p_load.add_argument('--indexing', action='store_true', help='update dictionary with words')
    p_load.add_argument('--move-file', action='store_true', help='move file to destination defined in config file')
    p_load.add_argument('--max-books', required=False, type=int, default=99999999, help='max number of books to be loaded\n\n'+C.gCyan())

    p_build = subparsers.add_parser("build", formatter_class=argparse.RawTextHelpFormatter, help="rebuild dictionary")
    p_build.add_argument('------------  build options', action='store_true', help=''+C.gYellow())  # solo per il colore
    p_build.add_argument('--force-indexing', action='store_true', help='update all records regardless indexed=true' )
    p_build.add_argument('--fields',
                                metavar='',
                                required=False,
                                default=['content'],
                                choices=['author', 'title', 'content'],
                                nargs='+',
                                help="fields to be indexed. BLANK separator\n\n")

    p_update_field = subparsers.add_parser ("update_field", formatter_class=argparse.RawTextHelpFormatter,  help="update specific field")
    p_update_field.add_argument('------------  update options', action='store_true', help=''+C.gYellow())  # solo per il colore
    p_test_field = subparsers.add_parser ("change_id", formatter_class=argparse.RawTextHelpFormatter, help="change id")
    p_test_field.add_argument('------------  test options', action='store_true', help=''+C.gYellow())  # solo per il colore


    for name, subp in subparsers.choices.items():
        common_options(subp)
    return parser

def post_process(args):
    # separazione degli args di tipo debug con quelli applicativi
    dbg=argparse.Namespace()
    log=argparse.Namespace()

    '''
    il processo che segue è per evitare:
       RuntimeError: dictionary changed size during iteration
       suddividiamo le varie options
    '''
    keys=list(args.__dict__.keys())
    _dargs=args.__dict__
    for key in keys:
        val=getattr(args, key)
        if key in ['log']:
            setattr(log, key, val)
        elif key.startswith('log_'):
            setattr(log, key[4:], val)
        elif key.startswith('+log'):
            pass # le ignoro in quanto servono solo ad impostare il valore
        elif key in ['debug']:
            setattr(dbg, key, val)
        elif 'debug options' in key:
            pass
        elif 'log options' in key:
            pass
        else:
            continue

        delattr(args, key)

    app=args


    if args.display_args:
        del args.display_args
        import json
        json_data = json.dumps(vars(app), indent=4, sort_keys=True)
        print('application arguments: {json_data}'.format(**locals()))
        json_data = json.dumps(vars(log), indent=4, sort_keys=True)
        print('logging arguments: {json_data}'.format(**locals()))
        json_data = json.dumps(vars(dbg), indent=4, sort_keys=True)
        print('debugging arguments: {json_data}'.format(**locals()))
        sys.exit(0)

    return app, log, dbg

##############################################################
# - Parse Input
##############################################################
def parseInput(color=None):
    global C
    C=color

    # =============================================
    # = Parsing
    # =============================================
    if len(sys.argv) <=2:
        sys.argv.append('-h')

    parser=mainOptions()

    args=parser.parse_args()
    return post_process(args)


